﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace l2l_aggregator.ViewModels
{
    public class ViewModelBase : ObservableObject
    {
    }
}
